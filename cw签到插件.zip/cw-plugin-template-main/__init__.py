from .main import Plugin
from .main import Settings  # 如果有定义设置类，则需要引入
