import sys
from PyQt5.QtWidgets import QFileDialog, QMessageBox, QVBoxLayout
from PyQt5.QtCore import Qt, QPropertyAnimation, QRect, QEasingCurve
from qfluentwidgets import CheckBox, MessageBox
from .ClassWidgets.base import PluginBase, SettingsBase
from .qiandao import Ui_MainWindow


class Plugin(PluginBase, Ui_MainWindow):  # 插件类
    def __init__(self, cw_contexts, method):  # 初始化
        super().__init__(cw_contexts, method)  # 调用父类初始化方法
        self.students = []
        self.signed_students = []
        self.setup_ui()

    def setup_ui(self):
        self.setupUi(self)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.move(300, 200)

        self.pushButton_4.clicked.connect(self.import_students)
        self.pushButton_3.clicked.connect(self.open_signin_dialog)
        self.pushButton.clicked.connect(self.closewidget)
        self.pushButton_2.clicked.connect(self.closewidget)

        self.widget_4_layout = QVBoxLayout(self.widget_4)

    def execute(self):  # 自启动执行部分
        self.show()

    def update(self, cw_contexts):  # 自动更新部分（每秒更新）
        super().update(cw_contexts)

    def import_students(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "选择学生名单文件", "", "文本文件 (*.txt)")
        if file_path:
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    self.students = [line.strip().split(".", 1)[-1] for line in f.readlines() if "." in line]
                self.signed_students.clear()
                self.update_checkboxes()
                self.peoplenum.setText(str(len(self.students)))
                self.textEdit_2.setText("\n".join(self.students))
                MessageBox("导入成功", f"成功导入 {len(self.students)} 名学生。", self.centralwidget).exec()
            except Exception as e:
                QMessageBox.critical(self, "错误", str(e))

    def update_checkboxes(self):
        try:
            for i in reversed(range(self.grid_layout.count())):
                widget = self.grid_layout.itemAt(i).widget()
                if widget:
                    widget.deleteLater()

            self.checkboxes = []
            self.cols = 4  # 每行最多 4 个
            for index, student in enumerate(self.students):
                cb = CheckBox(student)
                cb.setChecked(student in self.signed_students)
                cb.clicked.connect(lambda checked, s=student: self.toggle_signin(s, checked))
                row, col = divmod(index, self.cols)
                self.grid_layout.addWidget(cb, row, col)
                self.checkboxes.append(cb)
        except Exception as e:
            QMessageBox.critical(self, "错误", str(e))

    def toggle_signin(self, student, checked):
        if checked:
            if student not in self.signed_students:
                self.signed_students.append(student)
        else:
            if student in self.signed_students:
                self.signed_students.remove(student)
        self.update_signin_status()

    def confirm_signin(self):
        print("已签到:", self.signed_students)
        print("未签到:", [s for s in self.students if s not in self.signed_students])
        self.update_signin_status()

    def update_signin_status(self):
        self.textEdit.setText("\n".join(self.signed_students))
        self.textEdit_2.setText("\n".join([s for s in self.students if s not in self.signed_students]))
        self.qiandaonum.setText(str(len(self.signed_students)))

    def open_signin_dialog(self):
        if not self.students:
            MessageBox("警告", "请导入学生名单！", self.centralwidget).exec()
            return
        if self.widget_2.y() == 40:
            return
        self.animation = QPropertyAnimation(self.widget_2, b"geometry")
        self.animation.setDuration(1000)
        self.animation.setStartValue(QRect(0, -620, 1341, 631))
        self.animation.setEndValue(QRect(0, 40, 1341, 631))
        self.animation.setEasingCurve(QEasingCurve.OutExpo)
        self.animation.start()

    def closewidget(self):
        self.animation = QPropertyAnimation(self.widget_2, b"geometry")
        self.animation.setDuration(1000)
        self.animation.setStartValue(QRect(0, 40, 1341, 631))
        self.animation.setEndValue(QRect(0, -620, 1341, 631))
        self.animation.setEasingCurve(QEasingCurve.OutExpo)
        self.animation.start()


class Settings(SettingsBase):  # 设置类
    def __init__(self, plugin_path, parent=None):
        super().__init__(plugin_path, parent)
        """
        在这里写设置页面
        """
